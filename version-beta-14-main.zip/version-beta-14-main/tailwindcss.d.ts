// tailwindcss.d.ts
declare module 'tailwindcss/lib/util/flattenColorPalette' {
    const flattenColorPalette: (colors: any) => Record<string, string>;
    export default flattenColorPalette;
  }