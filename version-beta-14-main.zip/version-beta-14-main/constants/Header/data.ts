export const navLinks = [
    {
        name: "Home",
        href: "/"
    },
    {
        name: "About us",
        href: "/about"
    },
    {
        name: "Contact us",
        href: "/contact"
    }
]